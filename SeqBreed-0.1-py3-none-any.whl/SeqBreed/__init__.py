#!/usr/bin/env python
from __future__ import absolute_import
from . import genome
__version__ = "0.1"

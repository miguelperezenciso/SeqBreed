#!/usr/bin/env python
from __future__ import absolute_import
from SeqBreed import genome
from . import selection
__version__ = "0.1"

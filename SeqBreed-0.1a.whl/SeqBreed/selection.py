""" This module incorporates several methods to seamlessly implement selection
    in seqbreed software
    Main arguments
        - criterion: Random, Phenotype, BLUP, GBLUP, Sstep, ...
        - generation: discrete(nsize) / continuous
        - intensity: male, female
        - mating: assortative / random
    The main output is an extended pedigree with offspring of selected parents

    ok: gwas option, fdr option
    TODO:
    - optimize reading /writing snp data
    - Add qtn positions in gwas plot
    - add labels pca,
    - add xvalidation = cross_val_predict(lr, boston.data, y, cv=10)
    - ULL: check pedigree order in complex settings (BLUP / GSSTEP)
"""
import numpy as np
import pandas as pd
import gzip
import re
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.decomposition import PCA
from subprocess import run
from subprocess import getoutput
from scipy import stats
from rpy2.robjects.packages import importr
from rpy2.robjects.vectors import FloatVector
from sklearn.preprocessing import StandardScaler
from SeqBreed import genome
Rstats = importr('stats')

# executables dir
#binDir='/home/miguel/PycharmProjects/sbvb/'
# missing code, ULL: it must be float
MISSING = -999999.

#########
class Pca:
#########
    """ plots PCA of selected inds and markers """
    def __init__(self, X):
        self.X = X
        self.p = []

    def fit(self):
        ''' performs PCA on pop and chip snps '''
        pca = PCA(n_components=2)
        self.p = pca.fit(self.X).fit_transform(self.X)

    def plot(self, plotFile=None, labels=None):
        plt.title('PCA decomposition')
        if labels is None:
            plt.scatter(self.p[:, 0], self.p[:, 1])
        else:
            for i in range(max(labels)+1):
                plt.scatter(self.p[labels==i, 0], self.p[labels==i, 1], label='Gen '+str(i))
            plt.legend(loc='best')
        if plotFile is None:
            plt.show()
        else:
            plt.savefig(plotFile)

##########
class Gwas:
##########
    """ Implements GWAS
        - chip(Chip object): the SNPs used to perform the gwas
        - b(float array): regression coefficients
        - pvalue(float array)
        - qvalue(float array)
    """
    def __init__(self, chip):
        self.chip = chip
        self.b = []
        self.se = []
        self.pvalue = []
        self.qvalue = []

    def fit(self, gfeature=None, gfounders=None, pop=None, X=None, y=None, vcfFile=None, trait=0):
        """ carry out GWAS
            X with genotypes can be directly provided or obtained from either vcffile or pop
            y can be directly provided or obtained from pop object
            returns [ b, se, pvalue]
            can do for any trait=0:ntrait, or as provided in y vector
            - gfeature(Genome object), required if X and vcfFile are not provided
            - gfounders(GFounder object): required if X or vcfFile are not provided
            - pop(Population object): required if X or y are not provided
            - X(nind x nmkr array): contains genotypes
            - y(nind array): contains phenotypes
            - vcfFile(str): vcf file name with genotypes
            - trait(int): trait index to be used, overriden if y provided [0]
        """
        # get phenotype if y not provided
        if not y:
            nind = len(pop.inds)
            y = np.array(list(pop.inds[i].y[trait] for i in range(nind)))
        else:
            nind = len(y)
        # output
        out = np.array([])

        # generates vcfFile if not present
        if X is None and vcfFile is None:
            if gfeature is None or gfounders is None:
                sys.exit('ULL: Both gfeatures and gbase must be provided with pop in dogwas')
            vcfFile = self.chip.name + 'vcf.gz'
            print_vcf(vcfFile, pop.inds[:], gfeature, gfounders, self.chip)
            print(vcfFile + 'vcf file generated')

        # genotypes from vcfFile
        if X is None:
            f_open = gzip.open if vcfFile.endswith('.gz') else open
            sep = '\||/'
            with f_open(vcfFile) as f:
                for line in f:
                    try:
                        line = line.decode()
                    except AttributeError:
                        pass
                    if line.startswith('#'): continue
                    line = line.rstrip().split('\t')
                    genotypes = line[9:]
                    gt = []
                    for g in genotypes:
                        ig = g.split(':')[0]
                        gt.append(re.split(sep, ig))
                    # convert into 1D list and to int
                    gt = np.array(list((map(int, sum(gt, [])))))
                    # trick to join by individual genotypes, and then sum
                    gt = np.split(gt, nind)
                    gt = np.asarray(list(map(sum, gt)))
                    b, intercept, r_value, p_value, std_err = stats.linregress(gt, y)
                    out = np.append(out, [b, std_err, p_value])

        # genotypes provided in X
        else:
            for i in range(X.shape[0]):
                # trick to sum genotypes over haplotypes
                x = np.split(X[i, :], nind)
                x = np.asarray(list(map(sum, x)))
                b, intercept, r_value, p_value, std_err = stats.linregress(x, y)
                out = np.append(out, [b, std_err, p_value])

        out = out.reshape(len(out) // 3, 3)
        self.b, self.se, self.pvalue = out[:,0], out[:,1], out[:,2]
        # FDR obtained from R package
        self.fdr = np.asarray(Rstats.p_adjust(FloatVector(self.pvalue), method='fdr'))

    def plot(self, plotFile=None, fdr=None):
        """ GWAS plot, one color per chr
        - plotFile(str): file name where plot is printed, can be png , pdf ... [None]
          prints to STDOUT if undefined
        - fdr(bool): plots fdr instead of -log10 p-values
        """
        nchr = len(self.chip.nsnp)
        col = np.tile(['r','b'], nchr)[:nchr] # r/b color per chr
        col = np.repeat(col, self.chip.nsnp)
        # p-values are printed
        if fdr == None or fdr == False:
            plt.scatter(list(range(len(self.pvalue))), -np.log10(self.pvalue), c=col, marker='o')
            plt.ylabel('-log10 P-value')
        # FDR values are printed
        else:
            plt.scatter(list(range(len(self.pvalue))), -np.log10(self.fdr), c=col, marker='o')
            plt.ylabel('-log10 FDR')
        plt.title(self.chip.name)
        plt.xlabel('SNP')
        if plotFile != None:
            plt.savefig(plotFile)
        else:
            plt.show()

    def print(self, genome, gwasFile=None):
        """ prints to file or STDOUT
        - genome(Genome object): [req]
        - gwastFile(str): file name where gwas results are printed [None]
          prints to STDOUT if undefined
        """
        f = sys.stdout if gwasFile == None else open(qtnFile, 'w')
        f.write('#CHR POS COEFF SE PVALUE FDR' + '\n')
        isnp = -1
        for ichr in range(genome.nchr):
            cname = str(genome.chrs[ichr].name)
            for i in range(len(self.chip.ipos[ichr])):
                isnp += 1
                bpos = str(genome.chrs[ichr].pos[self.chip.ipos[ichr][i]])
                line = cname + ' ' + bpos + ' ' + str(self.b[i]) + ' ' + str(self.se[i]) \
                       + ' ' + str(self.pvalue[i]) + ' ' + str(self.fdr[i])
                f.write(line+'\n')
        pass



##########
def do_grm(X, grmFile=None, nh=2, maf=1e-6):
##########
    """ Computes GRM
        - X contains genotypes
        - grmFile(str): file name containing GRM [req]
          compressed if file name ends with 'gz'
        - nh: ploidy
        - maf(float): minimum maf for a snp to be considered [1e-6]
    """
    p = X.mean(axis=0)/nh
    c = nh * p * (1.-p)
    s = StandardScaler(with_std=False)
    X = s.fit_transform(X.T).T
    G = np.matmul(X.T, X) / c
    return G

'''
#########
def dogrm(vcfFile, grmFile, maf=1e-6):
#########
    """ Computes GRM using external program
        - vcfFile(str): file name with genotypes [req]
        - grmFile(str): file name containing GRM [req]
          compressed if file name ends with 'gz'
        - maf(float): minimum maf for a snp to be considered [1e-6]
    """
    if vcfFile.endswith('.gz'):
        cat = 'zcat '
    else:
        cat = 'cat '
    if grmFile.endswith('.gz'):
        gz = True
    else:
        gz = False
    # no. individuals
    cmd = cat + vcfFile + ' | grep -v "#" | head -n1 | awk "{print NF}"'
    nind = int(getoutput(cmd)) - 9
    # infer ploidy
    cmd = cat + vcfFile + ' | grep -v "#" | head -n1'
    ploidy = 1 + (getoutput(cmd).count('|') + getoutput(cmd).count('/')) // nind
    # compute GRM with external program
    cmd = cat + vcfFile + ' | grep -v "#" | cut -f10- | perl -pe "s/:.*?\t/\t/g" | sed "s/|/ /g" | sed "s/\// /g" | ' \
        + binDir + 'dogrm -nind ' + str(nind) + ' -ploidy ' + str(ploidy) + ' -maf ' + str(maf)
    if gz:
        cmd += ' | gzip > ' + grmFile
    else:
        cmd += ' > ' + grmFile
    run(cmd, shell=True)
'''

##########
def doAinv(pedFile, ainvFile, binDir ,invert=True):
##########
    """ Computes A or A-inverse using external function
        - pedFile(str): file name with pedigree [req]
        - ainvFile(str): file name containing NRM or NRM inverse [req]
	- binDir (str): dir where is compiled doa file [req] 
          compressed if file name ends with 'gz'
        - invert(bool): produces inverse (True) or direct A (False) [True]
    """
    if invert:
        inv = '-inv'
    else:
        inv = ' '
    nind = pd.read_csv(pedFile, header=None, comment='#').shape[0]
    cmd = 'cat ' + pedFile + ' | ' + binDir + 'doa ' + inv + ' -nind ' + str(nind) + ' '
    if ainvFile.endswith('gz'):
        cmd += '| gzip  > ' + ainvFile
    else:
        cmd += ' > ' + ainvFile
    run(cmd, shell=True)

###########
def dogblup(h2, y, grmFile=None, G=None, invert=True):
###########
    """ (G)BLUP evaluation, returns EBVs
        G can be passed as argument or printed in grmFile
        G is assumed to be the inverse if Invert=False
        - h2(float): h2 used [req]
        - y(array float): phenotypes, can contain missing values as coded by MISSING [req]
        - grmFile(str): file containing Cov matrix of breeding values or its inverse [None]
        - G(nind x nind float array): np.array with Cov matrix of breeding values or its inverse [None]
        - invert(bool): True if G should be inverted or False if already inverted [True]
    """
    # G is read from file
    if grmFile!=None:
        G = np.array(pd.read_csv(grmFile, header=None, comment='#', sep='\s+'))

    nind = len(y)
    if nind != G.shape[0]:
        sys.exit('GRM matrix size must be equal to no. inds')

    # builds MME
    if invert: 
        np.fill_diagonal(G, np.diag(G) * 1.05)
        lhs = np.linalg.inv(G)
    else:
        lhs = G

    y[y==MISSING] = 0
    x1 = np.repeat(1.,nind)
    x1[y==0] = 0
    x2 = np.append(x1, len(x1[x1!=0])) # last element is no. of data

    lhs = lhs * ((1.-h2)/h2)
    np.fill_diagonal(lhs, np.diag(lhs)+x1)
    lhs = np.vstack([lhs, x1])  # add row
    lhs = np.hstack((lhs, x2.reshape(nind+1,1))) # add col
    rhs = np.append(y, np.sum(y))

    # solves, all els but last are the ebvs
    ebv = np.linalg.solve(lhs, rhs)[:-1]
    return ebv


###########
def dosstep(h2, y, im, ainvFile, aFile, G=None, grmFile=None):
###########
    """ Single step evaluation
        - h2(float): h2 used [req]
        - y(array float): phenotypes, can contain missing values as coded by MISSING [req]
        - im(int array): set of genotyped individuals (indexed starting with 0) [req]
        - ainvFile(str): file name that contains A inverse [req]
        - aFile(str): file name that contains A [req]
        - grmFile(str): file name that contains GRM of genotyped individuals [req]
    """
    nind = len(y)
    A = np.array(pd.read_csv(aFile, header=None, comment='#', sep='\s+'))
    Ainv = np.array(pd.read_csv(ainvFile, header=None, comment='#', sep='\s+'))
    if nind != A.shape[0]: sys.exit('NRM matrix size must be equal to # inds')

    ngind = len(im)
    if grmFile!=None:
       G = np.array(pd.read_csv(grmFile, header=None, comment='#', sep='\s+'))
    np.fill_diagonal(G, np.diag(G) * 1.05)
    if ngind != G.shape[0]: sys.exit('GRM matrix size must be equal to # genotyped inds')

    # builds H-1
    Hinv = Ainv
    Ginv = np.linalg.inv(G)
    A22inv = np.linalg.inv(A[im,:][:,im])
    # ULLLL: this did not work!!!
    # Hinv[im,:][:,im] = Hinv[im,:][:,im] + Ginv - A22inv
    Z = Ginv - A22inv
    j=0
    for i in im:
        Hinv[i,im] += Z[j,:]
        j+=1

    ebv = dogblup(h2, y, G=Hinv, invert=False)
    return ebv

#########
def doEbv(pop, criterion='random', h2=None, X=None, grmFile=None, mkrIds=None, yIds=[], nh=2, itrait=0):
#########
    """ returns estimated breeding values (EBVs), assume selection is on first trait (itrait=0)
    - pop (Population object)
    - criterion(str): evaluation method: 'random', 'phenotype', 'blup', 'gblup', 'sstep' ['random']
    - h2(float): used h2, required in blup, gblup or sstep [None]
    - X: contains genotypes
    - grmFile(str): file containing Cov matrix of breeding values [None]
    - mkrIds(int array): set of genotyped individuals (indexed starting with 0) [None, req for sstep]
    - yIds(int array): integer array specifying individuals with data (indexed starting with 0) [all]
    - trait(int): trait index for which evaluation is performed [0]
    Either grmFile or G is required for gblup and sstep. In sstep, marker files should contain
    only information for genotyped individuals and in the same order.
    """
    criterion = criterion.lower()
    nind = len(pop.inds)

    # remove missing phenotypes ( none by default)
    if len(yIds)==0:
        yIds = np.arange(nind)
    y0 = np.array(list(pop.inds[i].y[itrait] for i in range(nind)))
    y = np.repeat(MISSING, nind)
    y[yIds] = y0[yIds]

    # check h2 is provided
    if criterion == 'blup' or criterion == 'gblup' or criterion=='sstep':
        if not h2: sys.exit('ULL: h2 must be specified for blup gblup or sstep')

    # computes A inverse required for blup or sstep
    if criterion == 'blup' or criterion=='sstep':
        # pedFile = str(np.random.randint(1e10)) + '.ped'
        pedFile = 'temp.ped'
        ped = pd.DataFrame(pop.ped())
        ped.to_csv(pedFile, sep=' ', header=None, index=False) # writes pedigree to file
        ainvFile = pedFile + '.ainv.gz'
        aFile = pedFile + '.a.gz'
        if criterion == 'blup':
            doAinv(pedFile, ainvFile, invert=True) #--> computes A-inv
        elif criterion == 'sstep':
            doAinv(pedFile, ainvFile, invert=True) # --> computes A-inv
            doAinv(pedFile, aFile, invert=False) #--> computes A

    # computes GRM if undefined, required for glbup or sstep
    if (criterion == 'gblup' or criterion=='sstep'):
        G = do_grm(X, nh)
        #grmFile = vcfFile + '.grm.gz' # compressed if name ends with 'gz'
        #dogrm(vcfFile, grmFile)

    # ---> Computes EBVs
    # pure drift
    if criterion == 'random':
        ebv = np.random.random(nind)
    # mass selection
    elif criterion == 'phenotype':
        ebv = y
    # BLUP
    elif criterion == 'blup':
        ebv = dogblup(h2, y, grmFile=ainvFile, invert=False)
    # GBLUP
    elif criterion == 'gblup':
        ebv = dogblup(h2, y, G=G, grmFile=None)
    # single step
    elif criterion == 'sstep':
        ebv = dosstep(h2, y, mkrIds, ainvFile, aFile, G=G, grmFile=None)
    # unknown
    else:
        sys.exit('Unknown selection criterion ' + criterion)

    # assigns EBV to individuals
    for i in range(nind):
        pop.inds[i].ebv = ebv[i]


################
def ReturnNewPed(pop, nsel, famsize, mating='random', generation=0):
################
    """ Returns a new pedigree given ebv and selection restrictions
    The new pedigree contains the offspring of selected individuals
    - pop(Population object)
    - nsel(int 2 els. array): number of males and females selected
    - famsize(int): number of offspring per female
    - mating(str): 'random' (=='r') or 'assortative' (=='a') [random]
    - generation(int): only individuals from generation onwards are considered as potential parents [all]
    """
    nind = len(pop.inds)
    ebv = np.array(list(pop.inds[i].ebv for i in range(nind)))
    sex = np.array(list(pop.inds[i].sex for i in range(nind)))
    # ULLL: note id-1 is referring to i
    id = np.array(list(pop.inds[i].id for i in range(nind))) - 1
    t = pop.t[id]

    # merge in temporary array [ebv, sex, t, id, index]
    temp = np.stack((ebv, sex, t, id, list(range(nind)))).T

    # select individuals from avail generations (all by default)
    temp = temp[temp[:,2]>=generation,:]

    # ix is indices selected males, note -ebv for decreasing order
    males = temp[temp[:,1]==0,:]
    ixmales = np.argsort(-males[:,0])[:nsel[0]]

    females = temp[temp[:,1]==1,:]
    ixfemales = np.argsort(-females[:,0])[:nsel[1]]

    # if not assortative mating (=random)
    if not mating.lower().startswith('a'):
        ixfemales = np.random.permutation(ixfemales)

    ped = []
    i = 0
    ij = -1
    for i in range(len(ixmales)):
        # NOTE: we need to add +1 to obtain id from index
        papa = int(temp[ixmales[i],3]) + 1
        for j in range(len(ixfemales)//len(ixmales)):
            ij += 1
            mama = int(temp[ixfemales[ij],3]) + 1 # idem
            for k in range(famsize):
                nind += 1
                sex = np.random.randint(0,2)
                ped.append([nind, papa, mama, sex])

    # returns pedigree of next generation
    return np.array(ped, int)
